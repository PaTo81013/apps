import 'package:flutter/material.dart';
import 'package:async/async.dart';
import 'package:http/http.dart' as http;

class Editar_Producto extends StatefulWidget {

  String? id;
  String? nombre;
  String? precio;
  String? descripcion;

  Editar_Producto(this.id,this.nombre,this.precio, this.descripcion);

  @override
  State<Editar_Producto> createState() => _Editar_ProductoState();
}

class _Editar_ProductoState extends State<Editar_Producto> {

  var c_nombre = TextEditingController();
  var c_precio = TextEditingController();
  var c_descripcion = TextEditingController();

  String nombre = '';
  String precio = '';
  String descripcion = '';

  Future<void> agregar()async{

    var url = Uri.parse('http://joussalonso.com/php/php/add_producto.php');

    var response = await http.post(url, body: {
      'id': widget.id,
      'nombre': nombre,
      'precio': precio,
      'descripcion':descripcion
    }).timeout(Duration(seconds: 90));

    if(response.body == '1'){

      c_nombre.text = '';
      c_precio.text = '';
      c_descripcion.text = '';

      Navigator.of(context).pop();

      print('Se subio el producto correctamente');

    }else{
      print(response.body);
    }

  }


  @override
  void initState(){
    super.initState();
    setState(() {
      c_nombre.text = widget.nombre!;
      c_precio.text = widget.precio!;
      c_descripcion.text = widget.descripcion!;
    });
  }


  Widget build(BuildContext context) {

    double ancho  = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Producto'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            TextField(
              controller: c_nombre,
              decoration: InputDecoration(
                  hintText: 'Nombre'
              ),
            ),
            SizedBox(height: 15,),
            TextField(
              controller: c_precio,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  hintText: 'Precio'
              ),
            ),
            SizedBox(height: 15,),
            TextField(
              controller: c_descripcion,
              decoration: InputDecoration(
                  hintText: 'Descripcion'
              ),
            ),
            SizedBox(height: 25,),
            ElevatedButton(
              onPressed: (){

                nombre = c_nombre.text;
                precio = c_precio.text;
                descripcion = c_descripcion.text;

                agregar();

              },
              child: Text('Agregar'),
            )
          ],
        ),
      ),
    );
  }
}