class Datos_Productos{

  String? id;
  String? nombre;
  String? precio;
  String? descripcion;

  Datos_Productos(this.id,this.nombre,this.precio,this.descripcion);

  Datos_Productos.fromJson(Map<String,dynamic>json){
    id = json['id'];
    nombre = json ['nombre'];
    precio = json['precio'];
    descripcion = json ['descripcion'];

  }

}
