import 'package:flutter/material.dart';

class Animales extends StatefulWidget {
  const Animales({super.key});

  @override
  State<Animales> createState() => _AnimalesState();
}

class _AnimalesState extends State<Animales> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Animales'),
      ),
      body: Center(
        child: Text('Animales',style: TextStyle(
          fontSize: 30
        ),),
      ),
    );
  }
}
