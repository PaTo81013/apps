import 'package:flutter/material.dart';
import 'package:http/http.dart'as http;
import 'package:async/async.dart';
import 'dart:convert';
import 'Datos_Productos.dart';
import 'Editar_Producto.dart';


class Productos extends StatefulWidget {
  const Productos({super.key});

  @override
  State<Productos> createState() => _ProductosState();
}

class _ProductosState extends State<Productos> {
  List<Datos_Productos>datos = [];
  Future<List<Datos_Productos>>tomar_datos()async{
    var url = Uri.parse('http://ricardo.tectorres.com/');
    var response = await http.post(url).timeout(Duration(seconds: 90));
    var datos = jsonDecode(response.body);

    List<Datos_Productos>registros =[];
    for(datos in datos){
      registros.add(Datos_Productos.fromJson(datos));
    }

    return registros;
  }

  mostrar_alerta(id,nombre) {
    showDialog(
      context: context,
      builder: (BuildContext context){
      return AlertDialog(
        title: Text('Precaucion'),
        content: SingleChildScrollView(
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.center,
           children: [
             const Text('Realmente quieres borrar este producto: '),
             Text(nombre)
           ],
         ),
        ),
        actions: [
          TextButton(
            onPressed: (){
                //eliminar_producto(id);
                Navigator.of(context).pop();
            },
            child: Text('Aceptar'),
          ),
          TextButton(
            onPressed: (){
              Navigator.of(context).pop();
            },
            child: Text('Cancelar'),
          ),
        ],
      );
      }
    );
    Future <void> eliminar_producto(id) async{
      var url = Uri.parse('http://joussalonso.com/php/php/add_producto.php');

      var response = await http.post(url, body: {
        'id': id,

      }).timeout(Duration(seconds: 90));

      if(response.body == '1'){

        print('Se subio el producto correctamente');

      }else{
        print(response.body);
      }
    }

  }
  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    super.setState(fn);
    tomar_datos().then((value){
      datos.addAll(value);
      print(datos.length);
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('Productos'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){},
        child: Icon(Icons.add),
        backgroundColor: Colors.lightGreen,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
            itemCount: datos.length,
            itemBuilder: (BuildContext context, int index){
              return Container(
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Colors.grey,width: 1)
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(datos[index].nombre!,style: TextStyle(
                        fontSize: 16
                      ),),
                    ),
                    GestureDetector(
                      onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (BuildContext context){
                          return Editar_Producto(datos[index].id,
                          datos[index].nombre, datos[index].precio, datos[index].descripcion,);
                            }
                        ));
                      },
                      child:  Icon(Icons.edit, color: Colors.amber,),
                    ),
                    SizedBox(width: 10,),
                    GestureDetector(
                      onTap: (){
                        mostrar_alerta(datos[index].id,datos[index].nombre);
                      },
                      child:  Icon(Icons.delete,color: Colors.red,),
                    ),
                  ],
                ),
              );
            },
            ),
          ),
        ],
      ),
      );
  }
}