import 'package:flutter/material.dart';

class Bienvenida extends StatefulWidget {
  String nombre;
  String correo;

  Bienvenida(this.nombre,this.correo);

  @override
  State<Bienvenida> createState() => _BienvenidaState();
}

class _BienvenidaState extends State<Bienvenida> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('bienvenido'),
      ),
      body: Center(
        child: Text('hola' + widget.nombre),
      ),
    );
  }
}
