import 'package:app/bienvenida.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:async/async.dart';
import 'dart:convert';

class Registro extends StatefulWidget {
  const Registro({Key? key}) : super(key: key);

  @override
  State<Registro> createState() => _RegistroState();
}

class _RegistroState extends State<Registro> {
  var c_nombre = TextEditingController();
  var c_correo = TextEditingController();
  var c_pass = TextEditingController();

  String? nombre = '';
  String? correo = '';
  String? pass = '';

  Future <void> enviar_datos() async{

    var url = Uri.parse('http://ricardo.tectorres.com/');

    var response = await http.post(url, body: {
      'nombre ': nombre,
      'correo': correo,
      'pass': pass,
    }).timeout(Duration(seconds: 90));

    print(response.body);
    var datos = jsonDecode(response.body);


    if (response.body == '1')
      {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (BuildContext context){
          return Bienvenida(datos['nombre'],datos['correo']);
          }
        ));
      }
    else
      {
        print(response.body);
      }


}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registro'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: ListView(
         

          children: [
            TextField(
              decoration: InputDecoration(
                  hintText: 'Nombre'
              ),
            ),
            SizedBox(height: 10,),
            TextField(
              decoration: InputDecoration(
                  hintText: 'correo'
              ),
            ),
            SizedBox(height: 10,),
            TextField(
              decoration: InputDecoration(
                  hintText: 'Constraseña'
              ),
            ),
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed: (){
                nombre = c_nombre.text;
                correo = c_correo.text;
                pass = c_pass.text;

                enviar_datos();

              },
              child: Text('Registrar'),
            )
          ],
        ),
      ),
    );
  }
}
