import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'dart:io';
import 'package:dio/dio.dart';

class Camara extends StatefulWidget {
  const Camara({Key? key}) : super(key: key);

  @override
  State<Camara> createState() => _CamaraState();
}

class _CamaraState extends State<Camara> {

  File? imagen  = null;
  final picker = ImagePicker();

  selimagen(op) async {

    var pickedFile;

    if(op == 1){
      pickedFile = await picker.pickImage(source: ImageSource.camera);
    }else{
      pickedFile = await picker.pickImage(source: ImageSource.gallery);
    }

    setState(() {

      if(pickedFile != null){
        //imagen = File(pickedFile.path);
        cortar(File(pickedFile.path));
      }else{
        print('No se selecciono nada');
      }

    });

  }

  cortar(picked) async{

    CroppedFile? cortado = await ImageCropper().cropImage(
        sourcePath: picked.path,
        aspectRatio: CropAspectRatio(ratioX: 1.0, ratioY: 1.0)
    );

    if(cortado != null ){
      setState(() {
        imagen = File(cortado!.path);
      });
    }

  }

  Dio dio = new Dio();
  Future<void> subirimagen() async{

    try{

      String filename = imagen!.path.split('/').last;

      FormData formData = FormData.fromMap({
        /*'usuario' : idusuario,
        'correo': correo**/
        'file': await MultipartFile.fromFile(
            imagen!.path, filename: filename
        )
      });

      await dio.post('http://joussalonso.com/php/php/subir_imagen.php',
          data: formData).then((value){

        if(value.toString() == '1'){
          print('Se subio la foto correctamente');
        }else{
          print(value.toString());
        }

      });

    }catch(e){
      print(e.toString());
    }

  }




  seleccionar(){

    showDialog(
        context: context,
        builder: (BuildContext context){
          return AlertDialog(
            contentPadding: EdgeInsets.all(0),
            content: SingleChildScrollView(
              child: Column(
                children: [
                  InkWell(
                    onTap: (){
                      selimagen(1);
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(width: 1, color: Colors.grey)
                          )
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text('Tomar una foto', style: TextStyle(
                                fontSize: 16
                            ),),
                          ),
                          Icon(Icons.camera_alt, color: Colors.blue,)
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      selimagen(2);
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(width: 1, color: Colors.grey)
                          )
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text('Seleccionar de Galeria', style: TextStyle(
                                fontSize: 16
                            ),),
                          ),
                          Icon(Icons.image, color: Colors.blue,)
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      padding: EdgeInsets.all(20),
                      color: Colors.red,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Cerrar', style: TextStyle(
                              fontSize: 16,
                              color: Colors.white
                          ),),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }
    );

  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Camara'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed:() {
                seleccionar();
              },
              child: Text('Tomar Foto'),
            ),
            SizedBox(height: 30,),
            ElevatedButton(
              onPressed:() {
                subirimagen();
              },
              child: Text('Subir Foto'),
            ),
            SizedBox(height: 20,),
            imagen == null ? Center() : Image.file(imagen!),

            SizedBox(height: 20,),
            Image.network('http://joussalonso.com/fotos/OV7pU8L89izY2pFsVp6rq7AVjIviey.jpg')


          ],
        ),
      ),
    );
  }
}