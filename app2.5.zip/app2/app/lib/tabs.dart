import 'package:flutter/material.dart';
import 'animales.dart';
import 'cosas.dart';
class Tabs extends StatefulWidget {
  const Tabs({super.key});

  @override
  State<Tabs> createState() => _TabsState();
}

class _TabsState extends State<Tabs> with SingleTickerProviderStateMixin {

  int selectedPage = 0;
  TabController? controller;

  @override
  void initState()
  {
    controller = TabController(length: 2, initialIndex: selectedPage, vsync: this);
  }
  @override
  void dispose()
  {
    super.dispose();
    controller!.dispose();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tabs'),
      ),
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(width: 1,color: Colors.lightBlueAccent),
              ),
            ),
            child: Material(
              color: Colors.deepOrange,
              child: TabBar(
                controller: controller,
                indicator: BoxDecoration(
                  color: Colors.orange,
                ),
                labelColor: Colors.black,
                unselectedLabelColor: Colors.white,
                tabs: [
                  Tab(child: Container(child: Text('animales'),),),
                  Tab(child: Container(child: Text('objetos'),),),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: controller,
              children: [
                Animales(),
                Cosa(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
