import 'package:flutter/material.dart';
class Cosa extends StatefulWidget {
  const Cosa({super.key});

  @override
  State<Cosa> createState() => _CosaState();
}

class _CosaState extends State<Cosa> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cosas'),
      ),
      body: Center(
        child: Text('Cosa',style: TextStyle(
            fontSize: 30
        ),),
      ),
    );
  }
}
