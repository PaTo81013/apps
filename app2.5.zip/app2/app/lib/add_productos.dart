import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Add_Productos extends StatefulWidget {
  const Add_Productos({Key? key}) : super(key: key);

  @override
  State<Add_Productos> createState() => _Add_ProductosState();
}

class _Add_ProductosState extends State<Add_Productos> {

  var c_nombre = TextEditingController();
  var c_precio = TextEditingController();
  var c_descripcion = TextEditingController();

  String nombre = '';
  String precio = '';
  String descripcion = '';

  Future<void> agregar()async{

    var url = Uri.parse('http://joussalonso.com/php/php/add_producto.php');

    var response = await http.post(url, body: {
      'nombre': nombre,
      'precio': precio,
      'descripcion':descripcion
    }).timeout(Duration(seconds: 90));

    if(response.body == '1'){

      c_nombre.text = '';
      c_precio.text = '';
      c_descripcion.text = '';

      Navigator.of(context).pop();

      print('Se subio el producto correctamente');

    }else{
      print(response.body);
    }

  }


  @override
  Widget build(BuildContext context) {

    double ancho  = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Producto'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            TextField(
              controller: c_nombre,
              decoration: InputDecoration(
                  hintText: 'Nombre'
              ),
            ),
            SizedBox(height: 15,),
            TextField(
              controller: c_precio,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  hintText: 'Precio'
              ),
            ),
            SizedBox(height: 15,),
            TextField(
              controller: c_descripcion,
              decoration: InputDecoration(
                  hintText: 'Descripcion'
              ),
            ),
            SizedBox(height: 25,),
            ElevatedButton(
              onPressed: (){

                nombre = c_nombre.text;
                precio = c_precio.text;
                descripcion = c_descripcion.text;

                agregar();

              },
              child: Text('Agregar'),
            )
          ],
        ),
      ),
    );
  }
}