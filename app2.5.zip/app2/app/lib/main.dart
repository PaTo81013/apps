import 'package:app/productos.dart';
import 'package:app/tabs.dart';
import 'package:flutter/material.dart';
import 'registro.dart';
import 'camara.dart';
import 'tabs.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Tabs(),
      debugShowCheckedModeBanner: false,
    );
  }
}